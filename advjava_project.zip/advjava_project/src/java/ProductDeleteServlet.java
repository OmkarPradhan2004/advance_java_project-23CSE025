import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/ProductDeleteServlet")
public class ProductDeleteServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Check if admin is logged in
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminName") == null) {
            response.sendRedirect("admin-login.jsp");
            return;
        }
        
        String productId = request.getParameter("id");
        
        if (productId == null || productId.isEmpty()) {
            response.sendRedirect("adminpanel.jsp?page=products&error=Invalid product ID");
            return;
        }
        
        Connection con = null;
        PreparedStatement pstmt = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
            
            // First delete related records (product images)
            String deleteImagesQuery = "DELETE FROM product_images WHERE product_id = ?";
            pstmt = con.prepareStatement(deleteImagesQuery);
            pstmt.setInt(1, Integer.parseInt(productId));
            pstmt.executeUpdate();
            pstmt.close();
            
            // Then delete the product
            String deleteProductQuery = "DELETE FROM products WHERE id = ?";
            pstmt = con.prepareStatement(deleteProductQuery);
            pstmt.setInt(1, Integer.parseInt(productId));
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                response.sendRedirect("adminpanel.jsp?page=products&success=Product deleted successfully");
            } else {
                response.sendRedirect("adminpanel.jsp?page=products&error=Product not found");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("adminpanel.jsp?page=products&error=Error deleting product: " + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
        }
    }
}