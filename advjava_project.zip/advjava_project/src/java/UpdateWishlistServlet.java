import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/UpdateWishlistServlet")
public class UpdateWishlistServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        HttpSession session = request.getSession();
        PrintWriter out = response.getWriter();
        
        // Create JSON response manually
        StringBuilder jsonResponse = new StringBuilder();
        
        // Check if user is logged in
        Integer userId = (Integer) session.getAttribute("userId");
        if (userId == null) {
            jsonResponse.append("{\"success\":false,\"message\":\"Please login to add items to wishlist\"}");
            out.print(jsonResponse.toString());
            out.flush();
            return;
        }
        
        String productIdStr = request.getParameter("productId");
        if (productIdStr == null || productIdStr.isEmpty()) {
            jsonResponse.append("{\"success\":false,\"message\":\"Product ID is required\"}");
            out.print(jsonResponse.toString());
            out.flush();
            return;
        }
        
        int productId;
        try {
            productId = Integer.parseInt(productIdStr);
        } catch (NumberFormatException e) {
            jsonResponse.append("{\"success\":false,\"message\":\"Invalid product ID\"}");
            out.print(jsonResponse.toString());
            out.flush();
            return;
        }
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
            
            // Check if the product is already in the wishlist
            String checkQuery = "SELECT id FROM wishlist WHERE user_id = ? AND product_id = ?";
            pstmt = conn.prepareStatement(checkQuery);
            pstmt.setInt(1, userId);
            pstmt.setInt(2, productId);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                // Product exists in wishlist, so remove it
                String deleteQuery = "DELETE FROM wishlist WHERE user_id = ? AND product_id = ?";
                pstmt = conn.prepareStatement(deleteQuery);
                pstmt.setInt(1, userId);
                pstmt.setInt(2, productId);
                int rowsAffected = pstmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    jsonResponse.append("{\"success\":true,\"action\":\"removed\",\"message\":\"Product removed from wishlist\"}");
                } else {
                    jsonResponse.append("{\"success\":false,\"message\":\"Failed to remove product from wishlist\"}");
                }
            } else {
                // Product doesn't exist in wishlist, so add it
                String insertQuery = "INSERT INTO wishlist (user_id, product_id) VALUES (?, ?)";
                pstmt = conn.prepareStatement(insertQuery);
                pstmt.setInt(1, userId);
                pstmt.setInt(2, productId);
                int rowsAffected = pstmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    jsonResponse.append("{\"success\":true,\"action\":\"added\",\"message\":\"Product added to wishlist\"}");
                } else {
                    jsonResponse.append("{\"success\":false,\"message\":\"Failed to add product to wishlist\"}");
                }
            }
            
        } catch (ClassNotFoundException e) {
            jsonResponse.append("{\"success\":false,\"message\":\"Database driver not found\"}");
            e.printStackTrace();
        } catch (SQLException e) {
            jsonResponse.append("{\"success\":false,\"message\":\"Database error: " + e.getMessage().replace("\"", "\\\"") + "\"}");
            e.printStackTrace();
        } catch (Exception e) {
            jsonResponse.append("{\"success\":false,\"message\":\"Unexpected error: " + e.getMessage().replace("\"", "\\\"") + "\"}");
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        out.print(jsonResponse.toString());
        out.flush();
    }
}