import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/AddCategoryServlet")
public class AddCategoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Check if admin is logged in
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminName") == null) {
            response.sendRedirect("admin-login.jsp");
            return;
        }
        
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        String isActive = request.getParameter("isActive");
        
        // Validate input
        if (name == null || name.trim().isEmpty()) {
            response.sendRedirect("adminpanel.jsp?page=categories&action=add&error=Category name is required");
            return;
        }
        
        Connection con = null;
        PreparedStatement pstmt = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
            
            String query = "INSERT INTO categories (name, description, is_active, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())";
            pstmt = con.prepareStatement(query);
            pstmt.setString(1, name.trim());
            pstmt.setString(2, description != null ? description.trim() : null);
            pstmt.setBoolean(3, "on".equals(isActive)); // Checkbox returns "on" when checked
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                response.sendRedirect("adminpanel.jsp?page=categories&success=Category added successfully");
            } else {
                response.sendRedirect("adminpanel.jsp?page=categories&action=add&error=Failed to add category");
            }
            
        } catch (SQLIntegrityConstraintViolationException e) {
            response.sendRedirect("adminpanel.jsp?page=categories&action=add&error=Category name already exists");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("adminpanel.jsp?page=categories&action=add&error=Error adding category: " + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
        }
    }
}