import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/SetDefaultAddressServlet")
public class SetDefaultAddressServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        
        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        int addressId = Integer.parseInt(request.getParameter("addressId"));
        
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
            
            // Remove default status from all addresses
            String removeDefaultSql = "UPDATE addresses SET is_default = FALSE WHERE user_id = ?";
            stmt = conn.prepareStatement(removeDefaultSql);
            stmt.setInt(1, userId);
            stmt.executeUpdate();
            stmt.close();
            
            // Set the selected address as default
            String setDefaultSql = "UPDATE addresses SET is_default = TRUE WHERE id = ? AND user_id = ?";
            stmt = conn.prepareStatement(setDefaultSql);
            stmt.setInt(1, addressId);
            stmt.setInt(2, userId);
            stmt.executeUpdate();
            
            response.sendRedirect("profile.jsp");
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("profile.jsp?error=set_default_failed");
        } finally {
            try { if (stmt != null) stmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
}