import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.RequestContext;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

@WebServlet("/AdminProductServlet")
@MultipartConfig(
    maxFileSize = 1024 * 1024 * 10,      // 10 MB
    maxRequestSize = 1024 * 1024 * 50    // 50 MB
)
public class AdminProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Database connection details
    private String jdbcURL = "jdbc:mysql://localhost:3306/ecommerce_db";
    private String jdbcUsername = "root";
    private String jdbcPassword = "2004";
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        if ("delete".equals(action)) {
            deleteProduct(request, response);
        } else {
            // Handle create/update with file uploads
            handleProductForm(request, response);
        }
    }
    
    private void handleProductForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            // Create a factory for disk-based file items
            DiskFileItemFactory factory = new DiskFileItemFactory();
            
            // Configure a repository (to ensure a secure temp location is used)
            ServletContext servletContext = this.getServletConfig().getServletContext();
            File repository = (File) servletContext.getAttribute("javax.servlet.context.tempdir");
            factory.setRepository(repository);
            
            // Create a new file upload handler
            ServletFileUpload upload = new ServletFileUpload(factory);
            
            // Parse the request
            List<FileItem> items = upload.parseRequest((RequestContext) request);
            
            // Process the form fields and files
            Map<String, String> fields = new HashMap<>();
            List<FileItem> fileItems = new ArrayList<>();
            
            for (FileItem item : items) {
                if (item.isFormField()) {
                    // Process regular form field
                    fields.put(item.getFieldName(), item.getString("UTF-8"));
                } else {
                    // Process form file field
                    if (!item.getName().isEmpty()) {
                        fileItems.add(item);
                    }
                }
            }
            
            // Get database connection
            conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            
            String action = fields.get("action");
            String productId = fields.get("id");
            
            if ("create".equals(action)) {
                // Insert product
                String sql = "INSERT INTO products (name, description, price, quantity, category_id, is_active) VALUES (?, ?, ?, ?, ?, ?)";
                pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                pstmt.setString(1, fields.get("name"));
                pstmt.setString(2, fields.get("description"));
                pstmt.setDouble(3, Double.parseDouble(fields.get("price")));
                pstmt.setInt(4, Integer.parseInt(fields.get("quantity")));
                pstmt.setInt(5, Integer.parseInt(fields.get("category_id")));
                pstmt.setBoolean(6, fields.containsKey("is_active"));
                
                int affectedRows = pstmt.executeUpdate();
                
                if (affectedRows > 0) {
                    // Get the generated product ID
                    rs = pstmt.getGeneratedKeys();
                    if (rs.next()) {
                        int newProductId = rs.getInt(1);
                        
                        // Save uploaded images
                        saveProductImages(conn, newProductId, fileItems);
                    }
                }
                
                response.sendRedirect("adminpanel.jsp?page=products&success=Product added successfully");
                
            } else if ("update".equals(action)) {
                // Update product
                String sql = "UPDATE products SET name=?, description=?, price=?, quantity=?, category_id=?, is_active=? WHERE id=?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, fields.get("name"));
                pstmt.setString(2, fields.get("description"));
                pstmt.setDouble(3, Double.parseDouble(fields.get("price")));
                pstmt.setInt(4, Integer.parseInt(fields.get("quantity")));
                pstmt.setInt(5, Integer.parseInt(fields.get("category_id")));
                pstmt.setBoolean(6, fields.containsKey("is_active"));
                pstmt.setInt(7, Integer.parseInt(productId));
                
                pstmt.executeUpdate();
                
                // Handle image updates
                handleImageUpdates(conn, Integer.parseInt(productId), fileItems, fields.get("removed_images"));
                
                response.sendRedirect("adminpanel.jsp?page=products&success=Product updated successfully");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("adminpanel.jsp?page=products&error=Error: " + e.getMessage());
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
    
    private void saveProductImages(Connection conn, int productId, List<FileItem> fileItems) 
            throws SQLException, IOException, Exception {
        
        PreparedStatement pstmt = null;
        
        try {
            String sql = "INSERT INTO product_images (product_id, image_url, is_primary) VALUES (?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            
            // Define the path where images will be stored
            String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }
            
            boolean isFirstImage = true;
            
            for (FileItem fileItem : fileItems) {
                if (!fileItem.getName().isEmpty()) {
                    // Generate a unique file name
                    String fileName = System.currentTimeMillis() + "_" + 
                                     (new File(fileItem.getName())).getName();
                    String filePath = uploadPath + File.separator + fileName;
                    File storeFile = new File(filePath);
                    
                    // Save the file on disk
                    fileItem.write(storeFile);
                    
                    // Save file path in database
                    String imageUrl = "uploads/" + fileName;
                    pstmt.setInt(1, productId);
                    pstmt.setString(2, imageUrl);
                    pstmt.setBoolean(3, isFirstImage); // First image is primary
                    pstmt.executeUpdate();
                    
                    isFirstImage = false;
                }
            }
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
        }
    }
    
    private void handleImageUpdates(Connection conn, int productId, List<FileItem> fileItems, String removedImages) 
            throws SQLException, IOException, Exception {
        
        PreparedStatement pstmt = null;
        
        try {
            // Remove images marked for deletion
            if (removedImages != null && !removedImages.trim().isEmpty()) {
                String[] removedImageIds = removedImages.split(",");
                String sql = "DELETE FROM product_images WHERE id = ?";
                pstmt = conn.prepareStatement(sql);
                
                for (String imageId : removedImageIds) {
                    if (!imageId.trim().isEmpty()) {
                        pstmt.setInt(1, Integer.parseInt(imageId.trim()));
                        pstmt.executeUpdate();
                    }
                }
            }
            
            // Save new images
            if (fileItems != null && !fileItems.isEmpty()) {
                saveProductImages(conn, productId, fileItems);
            }
            
            // Update primary image if specified
            // (You would need to implement this based on your UI)
            
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
        }
    }
    
    private void deleteProduct(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            String productId = request.getParameter("id");
            
            conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            
            // Delete product (this will cascade to product_images due to foreign key constraint)
            String sql = "DELETE FROM products WHERE id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, Integer.parseInt(productId));
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                response.sendRedirect("adminpanel.jsp?page=products&success=Product deleted successfully");
            } else {
                response.sendRedirect("adminpanel.jsp?page=products&error=Product not found");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("adminpanel.jsp?page=products&error=Error: " + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
}