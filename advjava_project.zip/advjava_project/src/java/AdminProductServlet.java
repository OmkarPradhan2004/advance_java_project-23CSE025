import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/AdminProductServlet")
public class AdminProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if ("delete".equals(action)) {
            String id = request.getParameter("id");
            
            Connection con = null;
            PreparedStatement pstmt = null;
            
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
                
                pstmt = con.prepareStatement("DELETE FROM products WHERE id = ?");
                pstmt.setInt(1, Integer.parseInt(id));
                int rowsAffected = pstmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    response.sendRedirect("adminpanel.jsp?page=products&success=Product deleted successfully");
                } else {
                    response.sendRedirect("adminpanel.jsp?page=products&error=Failed to delete product");
                }
                
            } catch (Exception e) {
                response.sendRedirect("adminpanel.jsp?page=products&error=" + e.getMessage());
            } finally {
                try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
                try { if (con != null) con.close(); } catch (Exception e) {}
            }
        }
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        String price = request.getParameter("price");
        String quantity = request.getParameter("quantity");
        String categoryId = request.getParameter("category_id");
        String isActive = request.getParameter("is_active");
        
        Connection con = null;
        PreparedStatement pstmt = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
            
            if ("create".equals(action)) {
                pstmt = con.prepareStatement("INSERT INTO products (name, description, price, quantity, category_id, is_active) VALUES (?, ?, ?, ?, ?, ?)");
                pstmt.setString(1, name);
                pstmt.setString(2, description);
                pstmt.setDouble(3, Double.parseDouble(price));
                pstmt.setInt(4, Integer.parseInt(quantity));
                pstmt.setInt(5, Integer.parseInt(categoryId));
                pstmt.setBoolean(6, isActive != null);
                
                int rowsAffected = pstmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    response.sendRedirect("adminpanel.jsp?page=products&success=Product added successfully");
                } else {
                    response.sendRedirect("adminpanel.jsp?page=products&error=Failed to add product");
                }
                
            } else if ("update".equals(action)) {
                String id = request.getParameter("id");
                
                pstmt = con.prepareStatement("UPDATE products SET name = ?, description = ?, price = ?, quantity = ?, category_id = ?, is_active = ? WHERE id = ?");
                pstmt.setString(1, name);
                pstmt.setString(2, description);
                pstmt.setDouble(3, Double.parseDouble(price));
                pstmt.setInt(4, Integer.parseInt(quantity));
                pstmt.setInt(5, Integer.parseInt(categoryId));
                pstmt.setBoolean(6, isActive != null);
                pstmt.setInt(7, Integer.parseInt(id));
                
                int rowsAffected = pstmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    response.sendRedirect("adminpanel.jsp?page=products&success=Product updated successfully");
                } else {
                    response.sendRedirect("adminpanel.jsp?page=products&error=Failed to update product");
                }
            }
            
        } catch (Exception e) {
            response.sendRedirect("adminpanel.jsp?page=products&error=" + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
        }
    }
}