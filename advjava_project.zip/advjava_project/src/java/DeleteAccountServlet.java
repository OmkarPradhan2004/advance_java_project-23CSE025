import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/DeleteAccountServlet")
public class DeleteAccountServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        
        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
            conn.setAutoCommit(false); // Start transaction
            
            // Delete user data from all related tables in proper order to maintain referential integrity
            
            // 1. Delete from wishlist
            String deleteWishlistSql = "DELETE FROM wishlist WHERE user_id = ?";
            stmt = conn.prepareStatement(deleteWishlistSql);
            stmt.setInt(1, userId);
            stmt.executeUpdate();
            stmt.close();
            
            // 2. Delete cart items and carts
            // First get cart IDs for this user
            String getCartIdsSql = "SELECT id FROM carts WHERE user_id = ?";
            stmt = conn.prepareStatement(getCartIdsSql);
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                int cartId = rs.getInt("id");
                // Delete cart items
                String deleteCartItemsSql = "DELETE FROM cart_items WHERE cart_id = ?";
                PreparedStatement cartItemsStmt = conn.prepareStatement(deleteCartItemsSql);
                cartItemsStmt.setInt(1, cartId);
                cartItemsStmt.executeUpdate();
                cartItemsStmt.close();
            }
            stmt.close();
            
            // Delete carts
            String deleteCartsSql = "DELETE FROM carts WHERE user_id = ?";
            stmt = conn.prepareStatement(deleteCartsSql);
            stmt.setInt(1, userId);
            stmt.executeUpdate();
            stmt.close();
            
            // 3. Delete addresses
            String deleteAddressesSql = "DELETE FROM addresses WHERE user_id = ?";
            stmt = conn.prepareStatement(deleteAddressesSql);
            stmt.setInt(1, userId);
            stmt.executeUpdate();
            stmt.close();
            
            // 4. For orders, we need to handle them carefully due to foreign key constraints
            // First get order IDs for this user
            String getOrderIdsSql = "SELECT id FROM orders WHERE user_id = ?";
            stmt = conn.prepareStatement(getOrderIdsSql);
            stmt.setInt(1, userId);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                int orderId = rs.getInt("id");
                
                // Delete payments
                String deletePaymentsSql = "DELETE FROM payments WHERE order_id = ?";
                PreparedStatement paymentsStmt = conn.prepareStatement(deletePaymentsSql);
                paymentsStmt.setInt(1, orderId);
                paymentsStmt.executeUpdate();
                paymentsStmt.close();
                
                // Delete order items
                String deleteOrderItemsSql = "DELETE FROM order_items WHERE order_id = ?";
                PreparedStatement orderItemsStmt = conn.prepareStatement(deleteOrderItemsSql);
                orderItemsStmt.setInt(1, orderId);
                orderItemsStmt.executeUpdate();
                orderItemsStmt.close();
            }
            stmt.close();
            
            // Delete orders
            String deleteOrdersSql = "DELETE FROM orders WHERE user_id = ?";
            stmt = conn.prepareStatement(deleteOrdersSql);
            stmt.setInt(1, userId);
            stmt.executeUpdate();
            stmt.close();
            
            // 5. Finally delete the user
            String deleteUserSql = "DELETE FROM users WHERE id = ?";
            stmt = conn.prepareStatement(deleteUserSql);
            stmt.setInt(1, userId);
            stmt.executeUpdate();
            
            // Commit transaction
            conn.commit();
            
            // Invalidate session
            session.invalidate();
            
            response.sendRedirect("login.jsp?message=account_deleted");
            
        } catch (Exception e) {
            try {
                if (conn != null) {
                    conn.rollback(); // Rollback transaction on error
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            response.sendRedirect("profile.jsp?error=delete_account_failed");
        } finally {
            try { if (stmt != null) stmt.close(); } catch (Exception e) {}
            try { 
                if (conn != null) {
                    conn.setAutoCommit(true); // Reset auto-commit
                    conn.close(); 
                }
            } catch (Exception e) {}
        }
    }
}