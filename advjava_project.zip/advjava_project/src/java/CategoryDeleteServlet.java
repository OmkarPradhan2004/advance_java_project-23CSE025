import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/CategoryDeleteServlet")
public class CategoryDeleteServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Check if admin is logged in
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminName") == null) {
            response.sendRedirect("admin-login.jsp");
            return;
        }
        
        String categoryId = request.getParameter("id");
        
        if (categoryId == null || categoryId.isEmpty()) {
            response.sendRedirect("adminpanel.jsp?page=categories&error=Invalid category ID");
            return;
        }
        
        Connection con = null;
        PreparedStatement pstmt = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
            
            // Check if category has products
            String checkProductsQuery = "SELECT COUNT(*) FROM products WHERE category_id = ?";
            pstmt = con.prepareStatement(checkProductsQuery);
            pstmt.setInt(1, Integer.parseInt(categoryId));
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next() && rs.getInt(1) > 0) {
                response.sendRedirect("adminpanel.jsp?page=categories&error=Cannot delete category with existing products");
                return;
            }
            
            pstmt.close();
            
            // Delete the category
            String deleteCategoryQuery = "DELETE FROM categories WHERE id = ?";
            pstmt = con.prepareStatement(deleteCategoryQuery);
            pstmt.setInt(1, Integer.parseInt(categoryId));
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                response.sendRedirect("adminpanel.jsp?page=categories&success=Category deleted successfully");
            } else {
                response.sendRedirect("adminpanel.jsp?page=categories&error=Category not found");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("adminpanel.jsp?page=categories&error=Error deleting category: " + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
        }
    }
}