import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class CategoryServlet
 * 
 * This servlet handles category filtering for the categories page.
 * It retrieves products based on the selected category.
 * 
 * @author Your Name
 * @version 1.0
 */
@WebServlet("/CategoryServlet")
public class CategoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/ecommerce_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "2004";

    /**
     * Handles GET requests for category filtering
     * 
     * @param request  the HttpServletRequest object containing the category parameter
     * @param response the HttpServletResponse object for forwarding to categories.jsp
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        
        // Get selected category if any
        String selectedCategory = request.getParameter("category");
        if (selectedCategory == null) selectedCategory = "all";
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            // Get all categories
            List<String[]> categories = new ArrayList<>();
            String categoryQuery = "SELECT * FROM categories WHERE is_active = TRUE ORDER BY name";
            pstmt = conn.prepareStatement(categoryQuery);
            rs = pstmt.executeQuery();
            
            while(rs.next()) {
                String[] category = new String[3];
                category[0] = rs.getString("id");
                category[1] = rs.getString("name");
                category[2] = rs.getString("description");
                categories.add(category);
            }
            
            request.setAttribute("categories", categories);
            
            // Get products based on category filter
            List<String[]> products = new ArrayList<>();
            String productQuery = "SELECT p.*, c.name as category_name, " +
                                 "(SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = TRUE LIMIT 1) as primary_image " +
                                 "FROM products p " +
                                 "LEFT JOIN categories c ON p.category_id = c.id " +
                                 "WHERE p.is_active = TRUE";
            
            if (!"all".equals(selectedCategory)) {
                productQuery += " AND p.category_id = ?";
            }
            
            productQuery += " ORDER BY p.created_at DESC";
            
            pstmt = conn.prepareStatement(productQuery);
            
            if (!"all".equals(selectedCategory)) {
                pstmt.setInt(1, Integer.parseInt(selectedCategory));
            }
            
            rs = pstmt.executeQuery();
            
            while(rs.next()) {
                String[] product = new String[8];
                product[0] = rs.getString("id");
                product[1] = rs.getString("name");
                product[2] = rs.getString("description");
                product[3] = rs.getString("price");
                product[4] = rs.getString("quantity");
                product[5] = rs.getString("category_name");
                product[6] = rs.getString("primary_image");
                product[7] = rs.getString("category_id");
                products.add(product);
            }
            
            request.setAttribute("products", products);
            request.setAttribute("selectedCategory", selectedCategory);
            
        } catch (Exception e) {
            request.setAttribute("errorMessage", "Error loading categories: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        // Forward to categories.jsp
        request.getRequestDispatcher("categories.jsp").forward(request, response);
    }
}