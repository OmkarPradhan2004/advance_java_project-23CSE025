import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AdminCategoryServlet")
public class AdminCategoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String adminName = (String) session.getAttribute("adminName");
        String adminEmail = (String) session.getAttribute("adminEmail");
        
        if (adminName == null || adminEmail == null) {
            response.sendRedirect("admin-login.jsp");
            return;
        }
        
        String action = request.getParameter("action");
        String redirectPage = "adminpanel.jsp?page=categories";
        String successMsg = "";
        String errorMsg = "";
        
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
            
            if ("create".equals(action)) {
                String name = request.getParameter("name");
                String description = request.getParameter("description");
                boolean isActive = "on".equals(request.getParameter("is_active"));
                
                String sql = "INSERT INTO categories (name, description, is_active) VALUES (?, ?, ?)";
                pstmt = con.prepareStatement(sql);
                pstmt.setString(1, name);
                pstmt.setString(2, description);
                pstmt.setBoolean(3, isActive);
                
                int rows = pstmt.executeUpdate();
                if (rows > 0) {
                    successMsg = "Category added successfully!";
                } else {
                    errorMsg = "Failed to add category.";
                }
            }
            else if ("update".equals(action)) {
                String id = request.getParameter("id");
                String name = request.getParameter("name");
                String description = request.getParameter("description");
                boolean isActive = "on".equals(request.getParameter("is_active"));
                
                String sql = "UPDATE categories SET name = ?, description = ?, is_active = ? WHERE id = ?";
                pstmt = con.prepareStatement(sql);
                pstmt.setString(1, name);
                pstmt.setString(2, description);
                pstmt.setBoolean(3, isActive);
                pstmt.setInt(4, Integer.parseInt(id));
                
                int rows = pstmt.executeUpdate();
                if (rows > 0) {
                    successMsg = "Category updated successfully!";
                } else {
                    errorMsg = "Failed to update category.";
                }
            }
            else if ("delete".equals(action)) {
                String id = request.getParameter("id");
                
                // First check if category has products
                String checkSql = "SELECT COUNT(*) as count FROM products WHERE category_id = ?";
                pstmt = con.prepareStatement(checkSql);
                pstmt.setInt(1, Integer.parseInt(id));
                rs = pstmt.executeQuery();
                
                if (rs.next() && rs.getInt("count") > 0) {
                    errorMsg = "Cannot delete category. It has products associated with it.";
                } else {
                    String deleteSql = "DELETE FROM categories WHERE id = ?";
                    pstmt = con.prepareStatement(deleteSql);
                    pstmt.setInt(1, Integer.parseInt(id));
                    
                    int rows = pstmt.executeUpdate();
                    if (rows > 0) {
                        successMsg = "Category deleted successfully!";
                    } else {
                        errorMsg = "Failed to delete category.";
                    }
                }
            }
            
        } catch (Exception e) {
            errorMsg = "Error: " + e.getMessage();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
            
            if (!successMsg.isEmpty()) {
                response.sendRedirect(redirectPage + "&success=" + java.net.URLEncoder.encode(successMsg, "UTF-8"));
            } else if (!errorMsg.isEmpty()) {
                response.sendRedirect(redirectPage + "&error=" + java.net.URLEncoder.encode(errorMsg, "UTF-8"));
            } else {
                response.sendRedirect(redirectPage);
            }
        }
    }
}