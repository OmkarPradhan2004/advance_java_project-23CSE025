import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/AddAddressServlet")
public class AddAddressServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        
        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String addressLine1 = request.getParameter("addressLine1");
        String addressLine2 = request.getParameter("addressLine2");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String zipCode = request.getParameter("zipCode");
        String country = request.getParameter("country");
        String phone = request.getParameter("phone");
        boolean isDefault = "true".equals(request.getParameter("isDefault"));
        
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
            
            // If this is set as default, remove default status from other addresses
            if (isDefault) {
                String removeDefaultSql = "UPDATE addresses SET is_default = FALSE WHERE user_id = ?";
                stmt = conn.prepareStatement(removeDefaultSql);
                stmt.setInt(1, userId);
                stmt.executeUpdate();
                stmt.close();
            }
            
            // Insert new address
            String insertSql = "INSERT INTO addresses (user_id, first_name, last_name, address_line1, " +
                             "address_line2, city, state, zip_code, country, phone, is_default) " +
                             "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(insertSql);
            stmt.setInt(1, userId);
            stmt.setString(2, firstName);
            stmt.setString(3, lastName);
            stmt.setString(4, addressLine1);
            stmt.setString(5, addressLine2 != null ? addressLine2 : "");
            stmt.setString(6, city);
            stmt.setString(7, state);
            stmt.setString(8, zipCode);
            stmt.setString(9, country != null ? country : "India");
            stmt.setString(10, phone);
            stmt.setBoolean(11, isDefault);
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                request.setAttribute("successMessage", "Address added successfully");
            } else {
                request.setAttribute("errorMessage", "Failed to add address");
            }
            
            RequestDispatcher dispatcher = request.getRequestDispatcher("profile.jsp");
            dispatcher.forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            RequestDispatcher dispatcher = request.getRequestDispatcher("profile.jsp");
            dispatcher.forward(request, response);
        } finally {
            try { if (stmt != null) stmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
}