import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AddProductServlet")
public class AddProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String adminName = (String) session.getAttribute("adminName");
        String adminEmail = (String) session.getAttribute("adminEmail");
        
        if (adminName == null || adminEmail == null) {
            response.sendRedirect("admin-login.jsp");
            return;
        }
        
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        String priceStr = request.getParameter("price");
        String quantityStr = request.getParameter("quantity");
        String categoryIdStr = request.getParameter("category_id");
        String isActive = request.getParameter("is_active");
        
        String redirectPage = "adminpanel.jsp?page=products";
        String successMsg = "";
        String errorMsg = "";
        
        Connection con = null;
        PreparedStatement pstmt = null;
        
        try {
            double price = Double.parseDouble(priceStr);
            int quantity = Integer.parseInt(quantityStr);
            int categoryId = Integer.parseInt(categoryIdStr);
            boolean activeStatus = "on".equals(isActive);
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
            
            String sql = "INSERT INTO products (name, description, price, quantity, category_id, is_active) VALUES (?, ?, ?, ?, ?, ?)";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, description);
            pstmt.setDouble(3, price);
            pstmt.setInt(4, quantity);
            pstmt.setInt(5, categoryId);
            pstmt.setBoolean(6, activeStatus);
            
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                successMsg = "Product added successfully!";
            } else {
                errorMsg = "Failed to add product.";
            }
            
        } catch (Exception e) {
            errorMsg = "Error: " + e.getMessage();
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
            
            if (!successMsg.isEmpty()) {
                response.sendRedirect(redirectPage + "&success=" + java.net.URLEncoder.encode(successMsg, "UTF-8"));
            } else if (!errorMsg.isEmpty()) {
                response.sendRedirect(redirectPage + "&error=" + java.net.URLEncoder.encode(errorMsg, "UTF-8"));
            } else {
                response.sendRedirect(redirectPage);
            }
        }
    }
}