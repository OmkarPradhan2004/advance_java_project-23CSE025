import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/UpdateOrderStatusServlet")
public class UpdateOrderStatusServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String adminName = (String) session.getAttribute("adminName");
        String adminEmail = (String) session.getAttribute("adminEmail");
        
        if (adminName == null || adminEmail == null) {
            response.sendRedirect("admin-login.jsp");
            return;
        }
        
        String id = request.getParameter("id");
        String status = request.getParameter("status");
        
        String redirectPage = "adminpanel.jsp?page=orders";
        String successMsg = "";
        String errorMsg = "";
        
        Connection con = null;
        PreparedStatement pstmt = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
            
            String sql = "UPDATE orders SET status = ? WHERE id = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, status);
            pstmt.setInt(2, Integer.parseInt(id));
            
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                successMsg = "Order status updated successfully!";
            } else {
                errorMsg = "Failed to update order status.";
            }
            
        } catch (Exception e) {
            errorMsg = "Error: " + e.getMessage();
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
            
            if (!successMsg.isEmpty()) {
                response.sendRedirect(redirectPage + "&success=" + java.net.URLEncoder.encode(successMsg, "UTF-8"));
            } else if (!errorMsg.isEmpty()) {
                response.sendRedirect(redirectPage + "&error=" + java.net.URLEncoder.encode(errorMsg, "UTF-8"));
            } else {
                response.sendRedirect(redirectPage);
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // For GET requests, show the status update form
        HttpSession session = request.getSession();
        String adminName = (String) session.getAttribute("adminName");
        String adminEmail = (String) session.getAttribute("adminEmail");
        
        if (adminName == null || adminEmail == null) {
            response.sendRedirect("admin-login.jsp");
            return;
        }
        
        String id = request.getParameter("id");
        request.setAttribute("orderId", id);
        request.getRequestDispatcher("update-order-status.jsp").forward(request, response);
    }
}