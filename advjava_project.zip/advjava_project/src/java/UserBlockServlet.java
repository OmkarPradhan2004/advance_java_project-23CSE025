import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/UserBlockServlet")
public class UserBlockServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Check if admin is logged in
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminName") == null) {
            response.sendRedirect("admin-login.jsp");
            return;
        }
        
        String userId = request.getParameter("id");
        
        if (userId == null || userId.isEmpty()) {
            response.sendRedirect("adminpanel.jsp?page=users&error=Invalid user ID");
            return;
        }
        
        Connection con = null;
        PreparedStatement pstmt = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
            
            String query = "UPDATE users SET is_active = FALSE WHERE id = ?";
            pstmt = con.prepareStatement(query);
            pstmt.setInt(1, Integer.parseInt(userId));
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                response.sendRedirect("adminpanel.jsp?page=users&success=User blocked successfully");
            } else {
                response.sendRedirect("adminpanel.jsp?page=users&error=User not found");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("adminpanel.jsp?page=users&error=Error blocking user: " + e.getMessage());
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
        }
    }
}