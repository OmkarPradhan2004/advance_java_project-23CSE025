import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/AddToCartServlet")
public class AddToCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        
        if (userId == null) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Please login first");
            return;
        }
        
        int productId = Integer.parseInt(request.getParameter("productId"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
            
            // Get or create cart for user
            int cartId = getOrCreateCart(conn, userId);
            
            // Check if product already in cart
            String checkSql = "SELECT id, quantity FROM cart_items WHERE cart_id = ? AND product_id = ?";
            stmt = conn.prepareStatement(checkSql);
            stmt.setInt(1, cartId);
            stmt.setInt(2, productId);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                // Update quantity
                int existingQuantity = rs.getInt("quantity");
                int newQuantity = existingQuantity + quantity;
                int itemId = rs.getInt("id");
                
                String updateSql = "UPDATE cart_items SET quantity = ?, updated_at = NOW() WHERE id = ?";
                stmt = conn.prepareStatement(updateSql);
                stmt.setInt(1, newQuantity);
                stmt.setInt(2, itemId);
                stmt.executeUpdate();
            } else {
                // Get product price
                String priceSql = "SELECT price FROM products WHERE id = ?";
                stmt = conn.prepareStatement(priceSql);
                stmt.setInt(1, productId);
                rs = stmt.executeQuery();
                
                if (rs.next()) {
                    double price = rs.getDouble("price");
                    
                    // Insert new cart item
                    String insertSql = "INSERT INTO cart_items (cart_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
                    stmt = conn.prepareStatement(insertSql);
                    stmt.setInt(1, cartId);
                    stmt.setInt(2, productId);
                    stmt.setInt(3, quantity);
                    stmt.setDouble(4, price);
                    stmt.executeUpdate();
                }
            }
            
            response.setContentType("text/plain");
            response.getWriter().write("success");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error adding to cart");
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (stmt != null) stmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
    
    private int getOrCreateCart(Connection conn, int userId) throws SQLException {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            String sql = "SELECT id FROM carts WHERE user_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("id");
            } else {
                // Create new cart
                String insertSql = "INSERT INTO carts (user_id) VALUES (?)";
                stmt = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS);
                stmt.setInt(1, userId);
                stmt.executeUpdate();
                
                rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (stmt != null) stmt.close(); } catch (Exception e) {}
        }
        
        return -1;
    }
}