import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/CheckoutServlet")
public class CheckoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        
        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        String address = request.getParameter("address");
        String paymentMethod = request.getParameter("paymentMethod");
        
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_db", "root", "2004");
            conn.setAutoCommit(false); // Start transaction
            
            // Get cart and items
            int cartId = getCartId(conn, userId);
            if (cartId == -1) {
                response.sendRedirect("cart.jsp?error=empty_cart");
                return;
            }
            
            // Calculate total
            double total = calculateCartTotal(conn, cartId);
            
            // Create order
            String orderSql = "INSERT INTO orders (user_id, total_amount, status, shipping_address, payment_method) VALUES (?, ?, 'pending', ?, ?)";
            stmt = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, userId);
            stmt.setDouble(2, total);
            stmt.setString(3, address);
            stmt.setString(4, paymentMethod);
            stmt.executeUpdate();
            
            rs = stmt.getGeneratedKeys();
            int orderId = -1;
            if (rs.next()) {
                orderId = rs.getInt(1);
            }
            
            // Move cart items to order items
            String moveItemsSql = "INSERT INTO order_items (order_id, product_id, quantity, price) " +
                                 "SELECT ?, product_id, quantity, price FROM cart_items WHERE cart_id = ?";
            stmt = conn.prepareStatement(moveItemsSql);
            stmt.setInt(1, orderId);
            stmt.setInt(2, cartId);
            stmt.executeUpdate();
            
            // Clear cart
            String clearCartSql = "DELETE FROM cart_items WHERE cart_id = ?";
            stmt = conn.prepareStatement(clearCartSql);
            stmt.setInt(1, cartId);
            stmt.executeUpdate();
            
            conn.commit(); // Commit transaction
            
            response.sendRedirect("order_confirmation.jsp?orderId=" + orderId);
        } catch (Exception e) {
            try { if (conn != null) conn.rollback(); } catch (Exception ex) {}
            e.printStackTrace();
            response.sendRedirect("checkout.jsp?error=checkout_failed");
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (stmt != null) stmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
    
    private int getCartId(Connection conn, int userId) throws SQLException {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            String sql = "SELECT id FROM carts WHERE user_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("id");
            }
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (stmt != null) stmt.close(); } catch (Exception e) {}
        }
        
        return -1;
    }
    
    private double calculateCartTotal(Connection conn, int cartId) throws SQLException {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            String sql = "SELECT SUM(quantity * price) as total FROM cart_items WHERE cart_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, cartId);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getDouble("total");
            }
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (stmt != null) stmt.close(); } catch (Exception e) {}
        }
        
        return 0;
    }
}